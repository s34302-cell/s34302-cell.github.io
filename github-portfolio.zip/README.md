# Portfolio Website

เว็บไซต์ Portfolio สำหรับนำขึ้น GitHub Pages

## วิธีใช้
1. แก้ `YOUR NAME`, `YOUR NICKNAME`, `YOUR SCHOOL` และข้อมูลต่าง ๆ ใน `index.html`
2. เปลี่ยนรูปในโฟลเดอร์ `images`
3. อัปโหลดไฟล์ทั้งหมดขึ้น GitHub Repository
4. เปิด GitHub Pages จาก Settings > Pages
